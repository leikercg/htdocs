<?php $__env->startSection('title', 'Administración de empleados'); ?>

<?php $__env->startSection('header', 'Administración de empleados'); ?>

<?php $__env->startSection('main_title', 'Insertar/modificar empleado'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(isset($employee)): ?>
        <br><br>
        <form action="<?php echo e(route('employee.update', ['employee' => $employee->id])); ?>" method="POST">
            <?php echo method_field('PATCH'); ?>
    <?php else: ?>
        <form action="<?php echo e(route('employee.store')); ?>" method="POST">
    <?php endif; ?>
        <?php echo csrf_field(); ?>
        <br>
        <table class='sinbordes'>
            <tr>
                <td class='sinbordes'>Nombre del empleado:</td>
                <td class='sinbordes'><input type="text" name="name" value="<?php echo e($employee->name ?? ''); ?>" required></td>
            </tr>
            <tr>
                <td class='sinbordes'>Apellidos:</td>
                <td class='sinbordes'><input type="text" name="surname" value="<?php echo e($employee->surname ?? ''); ?>" required></td>
            </tr>
            <tr>
                <td class='sinbordes'>Departamento:</td>
                <td class='sinbordes'><input type="text" name="department" value="<?php echo e($employee->department ?? ''); ?>" required></td>
            </tr>
            <tr>
                <td class='sinbordes'>Funciones:</td>
                <td class='sinbordes'><input type="text" name="functions" value="<?php echo e($employee->functions ?? ''); ?>" required></td>
            </tr>
            <tr>
                <td class='sinbordes'><a href="<?php echo e(route('employee.index')); ?>">Volver al listado</a></td>
                <td class='sinbordes'><input type="submit"></td>
            </tr>
        </table>
        </form>

    <br><br>
    <form action = "<?php echo e(route('menu')); ?>" method="GET" class="centrado">
        <?php echo csrf_field(); ?>
        <input type="submit" value="MENÚ PRINCIPAL">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Leiker_Castillo\xampp\htdocs\Laravel\examen_eva2\resources\views/employee/form.blade.php ENDPATH**/ ?>