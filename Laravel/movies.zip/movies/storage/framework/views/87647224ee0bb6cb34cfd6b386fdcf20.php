<?php $__env->startSection('Cartelera', $title); ?>

<?php $__env->startSection('main_title', $title); ?>

<?php $__env->startSection('content'); ?>
    <div id='pelicula'>

        <div><img src="<?php echo e(asset('images/' . $image)); ?>"></div>
            <div id="datos">
                <p><b>Director:</b><?php echo e($director->name); ?> <?php echo e($director->surname); ?></p>
                <p><b>Actor principal:</b><?php echo e($leadActor->name); ?> <?php echo e($leadActor->surname); ?></p>
                <?php $contador=1 ?>
                <?php $__currentLoopData = $writers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $writer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($contador == 1): ?>
                        <p ><b>Guionistas:</b><?php echo e($writer->name); ?> <?php echo e($writer->surname); ?></p>
                        <?php $contador++ ?>
                    <?php else: ?>
                        <p class="writer"><?php echo e($writer->name); ?> <?php echo e($writer->surname); ?></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <p><b>Fecha de estreno:</b><?php echo e($release_date); ?></p>
                <p><b>Duración:</b><?php echo e($duration); ?></p>
                <p><b>Género:</b><?php echo e($genre); ?></p>
            </div>



    </div>
    <div id="synopsis">
        <p><b>Synopsis:</b></p><p><?php echo e($synopsis); ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Leiker_Castillo\xampp\htdocs\Laravel\movies\resources\views/pelicula.blade.php ENDPATH**/ ?>