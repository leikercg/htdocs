<?php $__env->startSection('Cartelera', 'Peliculas'); ?>

<?php $__env->startSection('main_title', 'BUSQUEDA POR DIRECTOR: ' . $busqueda); ?>

<?php $__env->startSection('content'); ?>
    <div id='peliculas'>
<!--recibimos dos parámetros, busqueda que es lo escrito en el form y un array php-->
        <?php $contador=1; ?>
        <table>
            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($contador  == 1): ?>
                    <tr>
                <?php endif; ?>

                <td><a href="<?php echo e(route('pelicula', $movie->id)); ?>"><img class="portada"
                            src="<?php echo e(asset('images/' . $movie->image)); ?>" alt="Portada de la película"></a>
                </td>
                <?php if($contador == 3): ?>
                    </tr>
                    <?php $contador=0; ?>
                <?php endif; ?>
                <?php $contador++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Leiker_Castillo\xampp\htdocs\Laravel\movies\resources\views/director.blade.php ENDPATH**/ ?>