<?php $__env->startSection('Cartelera', $genero); ?>

<?php $__env->startSection('main_title', 'CATALOGO DE PELICULAS DE '. $genero); ?>

<?php $__env->startSection('content'); ?>
    <div id='peliculas'>
        <table>
            <?php $__currentLoopData = $movies->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td> <a href="<?php echo e(route('pelicula', ['id'=>$movie->id])); ?>"><img class="portada" src="<?php echo e(asset('images/'.$movie->image)); ?>"></a></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Leiker_Castillo\xampp\htdocs\Laravel\movies\resources\views/genero.blade.php ENDPATH**/ ?>