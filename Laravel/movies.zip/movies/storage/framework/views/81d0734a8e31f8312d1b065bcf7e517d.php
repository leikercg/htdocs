<html>
<head>
    <title><?php echo $__env->yieldContent('Cartelera'); ?></title><!--yield significa que aquí debera ser insertado lo que hay en la title content-->
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>"> 
    <link rel="stylesheet" href="/css/app.css">
    <script src="js/app.js" defer></script>

</head>

<body>
    <section>
        <nav>
            <img src='<?php echo e(asset('images/itsfree_header.gif')); ?>'>
            <div id="contenedorIzquierdo">
                <h3><a href="<?php echo e(route('mostrar')); ?>">PELICULAS ONLINE</a></h3>
                <div id="botonesIzquierdos">
                    <a href="<?php echo e(route('novedades',['fecha'=>'novedades'])); ?>">Últimas novedades</a>
                    <a href="<?php echo e(route('novedades',['fecha'=>'proximos'])); ?>">Próximos estrenos</a>
                </div>
                <form method="GET" action="<?php echo e(route('titulo')); ?>"> <!--Preguntar-->
                    <label for="titulo"><b>título</b></label>
                    <div>
                        <input class="campo" type="text" name="titulo" id="titulo"> <button>Lupa</button>
                    </div>
                </form>
                <form method="GET" action="<?php echo e(route('director')); ?>">
                    <label for="director"><b>director</b></label>
                    <div>
                        <input class="campo" type="text" name="director" id="director"> <button>Lupa</button>
                    </div>
                </form>
                <div id="generos">
                    <span><b>género</b></span>
                    <div>
                        <div class="fila">
                            <a href="<?php echo e(route('genero',['genero'=>'Acción'])); ?>">Acción</a>
                            <a href="<?php echo e(route('genero',['genero'=>'Aventura'])); ?>">Aventura</a>
                            <a href="<?php echo e(route('genero',['genero'=>'Ciencia ficción'])); ?>">Ciencia ficción</a>
                        </div>
                        <div class="fila">
                            <a href="<?php echo e(route('genero',['genero'=>'Comedia'])); ?>">Comedia</a>
                            <a href="<?php echo e(route('genero',['genero'=>'Drama'])); ?>">Drama</a>
                            <a href="<?php echo e(route('genero',['genero'=>'Historia'])); ?>">Historia</a>
                        </div>
                        <div class="fila">
                            <a href="<?php echo e(route('genero',['genero'=>'Fantasía'])); ?>">Fantasía</a>
                            <a href="<?php echo e(route('genero',['genero'=>'Animación'])); ?>">Animación</a>
                            <a href="<?php echo e(route('genero',['genero'=>'Romance'])); ?>">Romance</a>
                        </div>
                        <div id="terror">
                            <a href="<?php echo e(route('genero',['genero'=>'Terror'])); ?>">Terror</a>
                        </div>

                    </div>
                </div>
            </div>

        </nav>
        <main>

                <div id="contenedorDerecha">
                    <h3><?php echo $__env->yieldContent('main_title'); ?></h3>
                    <?php $__env->startSection('content'); ?>

                </div>

            <?php echo $__env->yieldSection(); ?>
        </main>
    </section>
</body>

</html>
<?php /**PATH D:\Leiker_Castillo\xampp\htdocs\Laravel\movies\resources\views/master.blade.php ENDPATH**/ ?>